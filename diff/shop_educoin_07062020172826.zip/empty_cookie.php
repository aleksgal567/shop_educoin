<?php
setcookie("basket","", 0 , "/");
echo "<h2>empty</h2>";
die();