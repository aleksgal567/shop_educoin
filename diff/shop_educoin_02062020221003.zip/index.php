<?php
include_once $_SERVER["DOCUMENT_ROOT"]."/parts/head.php";
include_once $_SERVER["DOCUMENT_ROOT"]."/parts/top_nav.php";
?>


<div class="container">
    <div class="row m-2">
        <div class="col-2">
            <?php
            include_once $_SERVER["DOCUMENT_ROOT"]."/parts/left_nav.php";
            ?>
        </div>
        <div class="col-10" id="content_column">
            <div class="container">
                <div class="row" id="cards_container">
                    <?php
                    $currentPage = 1;
                    $productsOnPage = 6;
                    include_once $_SERVER["DOCUMENT_ROOT"]."/parts/index_cards.php";
                    ?>
                </div>
                <div class="row">
                    <div class="col-4 offset-4" id="show-more">
                        <input type="hidden" value="<?=$currentPage;?>" id="current_page">
                        <input type="hidden" value="<?=$productsOnPage;?>" id="products-on-page">
                        <button class="btn btn-primary">показать еще</button>
                    </div>
                </div>
            </div>

        </div><!--/#content_column-->
    </div>
</div><!-- /.container -->


<?php
include_once $_SERVER["DOCUMENT_ROOT"]."/parts/bottom.php";