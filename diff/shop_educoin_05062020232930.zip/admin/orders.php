<?php
include_once "functions.php";
include_once "variables.php";
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <?php include_once "parts/head.php"; ?>
</head>
<body>
<div class="wrapper">
    <?php include_once "parts/left_nav.php"; ?>
    <div class="main-panel">
        <?php include_once "parts/top_admin_nav.php";?>
        <div class="content">
            <div class="container-fluid" id="working_container">
                <?php include_once "options/table_orders.php";?>

                <!-- <div class="row"></div>-->
            </div>
        </div>
    </div>
</div>
</body>
<?php include_once "parts/footer_scripts.php"; ?>
</html>