<?php
include_once $_SERVER["DOCUMENT_ROOT"]."/parts/head.php";
include_once $_SERVER["DOCUMENT_ROOT"]."/parts/top_nav.php";
?>


    <div class="container">
        <div class="row m-2">
            <div class="col-2">
                <?php
                include_once $_SERVER["DOCUMENT_ROOT"]."/parts/left_nav.php";
                ?>
            </div>
            <div class="col-10" id="content_column">
                <div class="container">
                    <form id="order-form">
                    <div class="row">
                        <table class="table table-striped" id="basket-table">
                          <?php include_once $_SERVER["DOCUMENT_ROOT"]."/parts/basket_table.php";?>
                        </table>
                    </div>
                    <div class="row">
                            <div class="form-row align-items-center">
                                <div class="col-auto">
                                    <label class="sr-only" for="inlineFormInput">Name</label>
                                    <input type="text" class="form-control mb-2" name="user_name" placeholder="Иванов">
                                </div>
                                <div class="col-auto">
                                    <label class="sr-only" for="inlineFormInputGroup">email</label>
                                    <div class="input-group mb-2">
                                        <div class="input-group-prepend">
                                            <div class="input-group-text">@</div>
                                        </div>
                                        <input type="text" class="form-control" name="user_email" placeholder="email">
                                    </div>
                                </div>
                                <div class="col-auto">
                                    <label class="sr-only" for="inlineFormInputGroup">phone</label>
                                    <div class="input-group mb-2">
                                        <div class="input-group-prepend">
                                            <div class="input-group-text"><img src="/img/volume-off.svg" alt=""></div>
                                        </div>
                                        <input type="text" class="form-control" name="user_phone" placeholder="phone">
                                    </div>
                                </div>

                                <div class="col-auto">
                                    <button id="send-order" name="button" value="button" class="btn btn-primary mb-2" onclick="sendOrder();return false;">Оформить</button>
                                </div>
                            </div>
                    </div>
                    </form><!--замахался с субмит и превент дефаулт-->
<div class="row">
    <button class="btn btn-danger" onclick="clearBasket();">Очистить корзину</button>
</div>
                </div>
            </div><!--/#content_column-->
        </div>
    </div><!-- /.container -->


<?php
include_once $_SERVER["DOCUMENT_ROOT"]."/parts/bottom.php";