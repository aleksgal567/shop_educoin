<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Shop EduCoin</title>
    <link rel="stylesheet" href="css/bootstrap.min.css">
</head>
<body>