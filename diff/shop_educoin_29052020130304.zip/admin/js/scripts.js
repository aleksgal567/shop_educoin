var editProdButton = null;
initEditProdButton();
function initEditProdButton(){
    editProdButton = document.querySelectorAll(".product-edit");
    editProdButton.forEach(function (item,i) {
        item.onclick = function(){
            let working_container = document.querySelector("#working_container");
            working_container.innerHTML = getAjaxResponse('/admin/options/product.php?act=edit&id='+item.dataset.id);
            initAllInitNeed();
        }
    });
}


var delProdButton = null;
initDelProdButton();
function initDelProdButton(){
    delProdButton = document.querySelectorAll(".product-delete");
    delProdButton.forEach(function (item,i) {
        item.onclick = function(){
            let working_container = document.querySelector("#working_container");
            working_container.innerHTML = getAjaxResponse('/admin/options/product.php?act=del&id='+item.dataset.id);
            initAllInitNeed();
        }
    });
}

function initAllInitNeed(){
    initEditProdButton();
    initDelProdButton();
    initAddProduct();
}

let addProduct = null;
function initAddProduct(){
    addProduct = document.querySelector("#add_product");
    addProduct.onclick = function(){
        let working_container = document.querySelector("#working_container");
        working_container.innerHTML = getAjaxResponse('/admin/options/product.php?act=create');
    }
}



function createEditProduct(){
    let createEditProdForm = document.querySelector("#create_edit_prod_form");
        let dataArr = [];
        for(let i = 0; i < createEditProdForm.length; i++) {
            dataArr.push(createEditProdForm[i].name+ "="+createEditProdForm[i].value)
        }
        let xhr = new XMLHttpRequest();
        let myLink = location.protocol+'//'+location.hostname+'/admin/options/product.php';

        xhr.open( "POST", myLink );
        xhr.setRequestHeader( "Content-type", "application/x-www-form-urlencoded" );

        xhr.send( dataArr.join("&") );
        xhr.onreadystatechange = function() {
            if (this.readyState != 4) return;
            if (this.status == 200) {
                let working_container = document.querySelector("#working_container");
                working_container.innerHTML =this.response;
                initAllInitNeed();
                return;
            }
        }
        return false;
}





/**
 * тип строки '/admin/options/product.php?act=create'
  */
function getAjaxResponse(url_string) {
    let myLink = location.protocol+'//'+location.hostname+url_string;
    let xhr = new XMLHttpRequest();
    xhr.open('GET', myLink, false);

    xhr.send();
    if (xhr.status != 200) {
        alert(`Ошибка ${xhr.status}: ${xhr.statusText}`);
        return null;
    } else {
        return xhr.response;
    }
    return null;
}