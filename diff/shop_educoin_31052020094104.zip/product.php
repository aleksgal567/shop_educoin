<?php
include_once $_SERVER["DOCUMENT_ROOT"]."/parts/head.php";
include_once $_SERVER["DOCUMENT_ROOT"]."/parts/top_nav.php";
?>


    <div class="container">
        <div class="row m-2">
            <div class="col-2">
                <div class="nav flex-column nav-pills" id="v-pills-tab" role="tablist" aria-orientation="vertical">
                    <a class="nav-link active" href="index.php">Назад</a>
                </div>
            </div>
            <div class="col-10" id="content_column">
                <div class="container">
                    <div class="row">
                        <?php
                        include_once $_SERVER["DOCUMENT_ROOT"]."/admin/functions.php";
                        var_dump(getPageDataById($_GET["product"]));
                        ?>
                    </div>

                </div>

            </div><!--/#content_column-->
        </div>
    </div><!-- /.container -->


<?php
include_once $_SERVER["DOCUMENT_ROOT"]."/parts/bottom.php";