var  btnShowMore = document.querySelector("#show-more");
btnShowMore.onclick = function () {
    let currentPage = document.querySelector("#current_page");
console.log(currentPage.value);

    let productsOnPage = document.querySelector("#products-on-page");
    let cards_container = document.querySelector("#cards_container");
    cards_container.innerHTML = cards_container.innerHTML + getAjaxResponse('/parts/showmore.php?page='+currentPage.value+'&limit='+productsOnPage.value);
    currentPage.value  = parseInt(currentPage.value, 10) +1;
}




/*

function selectCategory() {
    let curSel = document.querySelector("#select-category");
    document.cookie = "sel_cat="+curSel.value;
    let working_container = document.querySelector("#working_container");
    working_container.innerHTML = getAjaxResponse('/admin/options/product.php?act=selcat&val='+curSel.value);
    initAllInitNeed();
}
*/


/**
 * тип строки '/admin/options/product.php?act=create'
 */
function getAjaxResponse(url_string) {
    let myLink = location.protocol+'//'+location.hostname+url_string;
    let xhr = new XMLHttpRequest();
    xhr.open('GET', myLink, false);

    xhr.send();
    if (xhr.status != 200) {
        alert(`Ошибка ${xhr.status}: ${xhr.statusText}`);
        return null;
    } else {
        return xhr.response;
    }
    return null;
}