<?php
include_once $_SERVER["DOCUMENT_ROOT"] . "/admin/functions.php";

$limit = null;
if (isset($_GET["limit"]) && isset($_GET["page"])){
    $limit = $_GET["limit"] * $_GET["page"] - $_GET["limit"];
}
if (isset($_GET["category"])){
    $products = getProducts($_GET["category"], $productsOnPage, $limit);
}else{
    $products = getProducts(null, $productsOnPage, $limit);
}

if($products){
    foreach ($products as $product) {
        ?>
        <div class="card col-3 m-2">
            <img src="<?=$product["image"];?>" class="card-img-top" alt="...">
            <div class="card-body">
                <h5 class="card-title"><?=$product["title"];?></h5>
                <p class="card-text"><?=$product["description"];?></p>
                <a href="product.php?product=<?=$product["id"];?>" class="btn btn-primary">Подробнее</a>
            </div>
        </div>
        <?php
    }
}else{
    echo "<h2>Нет товаров</h2>";
}

?>


