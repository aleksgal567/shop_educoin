<div class="sidebar" data-image="assets/img/sidebar-5.jpg">
    <div class="sidebar-wrapper">
        <div class="logo">
            <a href="http://shop.educoin" class="simple-text">
                На сайт
            </a>
        </div>
        <ul class="nav">
            <?php
            viewLeftNav();
            ?>
        </ul>
    </div>
</div>