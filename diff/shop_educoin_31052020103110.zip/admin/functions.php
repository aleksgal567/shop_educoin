<?php
include_once "db.php";
include_once "variables.php";


/**
 * получить продукты
 * @return array|null
 */
function getProducts($category = null){
    global $link;
    $query = "SELECT `id`, `title`, `description`, `content`, `image`, `id_category` FROM `products` WHERE `deleted` = 0";

    if(!is_null($category) && $category != "0")
   // if(!$category)
        $query .= " AND `id_category`=".$category;

    $result = mysqli_query($link, $query);
    if(!$result)
        return null;
    $temp_arr = [];
    while ($row = mysqli_fetch_assoc($result)) {
        $temp_arr[] = $row;
    }
    mysqli_free_result($result);
    return $temp_arr;
}

/**
 * получить продукт по айди
 * @param $id
 * @return string[]|null
 */
function getProductById($id){
    global $link;
    $query = "SELECT `id`, `title`, `description`, `content`, `image`, `id_category` FROM `products` WHERE `id` = ".$id;

    $result = mysqli_query($link, $query);
    if(!$result)
        return null;
    $row = mysqli_fetch_assoc($result);

    mysqli_free_result($result);
    return $row;
}

/**
 * получить пустой массив продукта
 * @return string[]
 */
function getEmptyProductArray(){
    return array("id"=> "0", "title"=>"", "description"=> "", "content"=> "", "image"=> "", "id_category"=> "0");
}

/**
 * вставить продукт в базу . (`title`, `description`, `content`, `image`, `id_category`)
 * @param $product
 * @return bool|mysqli_result
 */
function insertProduct($product){
    global $link;
    $query = "INSERT INTO `products` ( `title`, `description`, `content`, `image`, `id_category`)
    VALUES ( '".$product["title"]."', '".$product["description"]."',
     '".$product["content"]."', '".$product["image"]."', '".$product["id_category"]."')";
    $result = mysqli_query($link, $query);
    return $result;
}

/**
 * обновить продукт
 * @param $product
 * @return bool|mysqli_result
 */
function updateProduct($product){
    global $link;
    $query = "UPDATE `products` SET `title` = '".$product["title"]."',
     `description` = '".$product["description"]."', 
     `content` = '".$product["content"]."', 
     `image` = '".$product["image"]."', 
     `id_category` = '".$product["id_category"]."' WHERE `id` = ".$product["id"];

    $result = mysqli_query($link, $query);
    return $result;
}

/**
 * удалить продукт
 * @param $id
 * @return bool|mysqli_result
 */
function deleteProduct($id){
    global $link;
    $query = "UPDATE `products` SET `deleted` = '1' WHERE `id` = ".$id;
    $result = mysqli_query($link, $query);
    return $result;
}


/**
 * пролучить все категории
 * @return array|null
 */
function getCategories(){
    global $link;
    $query = "SELECT `id`, `title`, `description` FROM `categories` WHERE `deleted`=0";

    $result = mysqli_query($link, $query);
    if(!$result)
        return null;
    $temp_arr = [];
    while ($row = mysqli_fetch_assoc($result)) {
        $temp_arr[] = $row;
    }
    mysqli_free_result($result);
    return $temp_arr;
}

/**
 * удалить категорию
 * @param $id
 * @return bool|mysqli_result
 */
function deleteCategory($id){
    global $link;
    $query = "UPDATE `categories` SET `deleted` = '1' WHERE `id` = ".$id;
    $result = mysqli_query($link, $query);
    return $result;
}

/**
 * вставить категорию. тип массива ( `title`, `description`)
 * @param $category
 * @return bool|mysqli_result
 */
function insertCategory($category){
    global $link;
    $query = "INSERT INTO `categories` ( `title`, `description`) 
            VALUES ( '".$category["title"]."', '".$category["description"]."');";
    $result = mysqli_query($link, $query);
    return $result;
}

function getCategoryById($id){
    global $link;
    $query = "SELECT `id`, `title`, `description` FROM `categories` WHERE `id` = ".$id;

    $result = mysqli_query($link, $query);
    if(!$result)
        return null;
    $row = mysqli_fetch_assoc($result);

    mysqli_free_result($result);
    return $row;
}

/**
 * обновить категорию
 * @param $category
 * @return bool|mysqli_result
 */
function updateCategory($category){
    global $link;
    $query = "UPDATE `categories` 
        SET `title` = '".$category["title"]."', `description` = '".$category["description"]."' 
        WHERE `id` = ".$category["id"];
    $result = mysqli_query($link, $query);
    return $result;
}

function getEmptyCategoryArray(){
    return array("id"=> "0", "title"=>"", "description"=> "");
}

/**
 * получить название категории
 * @param $id
 * @return mixed|string
 */
function getCategoryName($id){
    global $link;
    $query = "SELECT `title` FROM `categories` WHERE `id`=".$id;
    $result = mysqli_query($link, $query);
    $row = mysqli_fetch_assoc($result);
    mysqli_free_result($result);
    return $row["title"];
}

function viewSelectCategories($categories, $selected=null){
    if (!is_null($selected) && $selected != "0")
        echo "<option value=\"0\" selected>Choose...</option>";
    foreach ($categories as $category){
        ?>
        <option value="<?=$category["id"];?>" <?=($selected == $category["id"]?"selected":"");?>><?=$category["title"];?></option>
        <?php
    }
}






/**
 * вывод данных страницы
 * @return string[]|null
 */
function getPageData(){
    global $link;
    $query = "SELECT `id`,`description`,`url`,`title` FROM `pages`
         WHERE`url`LIKE \"".basename($_SERVER["PHP_SELF"])."\"";

    $result = mysqli_query($link, $query);
    if(!$result)
        return null;

    $row = mysqli_fetch_assoc($result);
    mysqli_free_result($result);
    return $row;
}

/**
 * данные страницы по айди
 * @param $id
 * @return string[]|null
 */
function getPageDataById($id){
    global $link;
    $query = "SELECT `id`,`description`,`url`,`title` FROM `pages`
         WHERE`id` = ".$id;

    $result = mysqli_query($link, $query);
    if(!$result)
        return null;

    $row = mysqli_fetch_assoc($result);
    mysqli_free_result($result);
    return $row;
}

/**
 * вывод админ навигации
 * @return string
 */
function viewLeftNav(){
    global $link;
    $query = "SELECT `id`,`description`,`url`,`title`, `ico` FROM `pages` 
        WHERE `admin_side`=1 ORDER BY `order_menu` ASC";
    $result = mysqli_query($link, $query);
    if(!$result)
        return "";
    while ($row = mysqli_fetch_assoc($result)) {
        ?>
        <li class="nav-item <?=(basename($_SERVER["PHP_SELF"]) == $row["url"])?"active":"";?>">
            <a class="nav-link" href="<?=$row["url"];?>">
                <i class="<?=$row["ico"];?>"></i>
                <p><?=$row["title"];?></p>
            </a>
        </li>
<?php
    }
    mysqli_free_result($result);
}