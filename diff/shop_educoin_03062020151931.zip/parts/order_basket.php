<?php
include_once $_SERVER["DOCUMENT_ROOT"] . "/admin/functions.php";
setcookie("basket","", 0 , "/");
if (isset($_POST)){
    if (insertOrder($_POST)){
        echo "ok";
    }else{
        echo "no";
    }
}

