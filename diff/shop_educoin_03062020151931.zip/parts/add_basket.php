<?php
include_once $_SERVER["DOCUMENT_ROOT"] . "/admin/functions.php";
if (isset($_POST) && $_SERVER["REQUEST_METHOD"] == "POST"){

    if (isset($_COOKIE["basket"])){
        $basket = json_decode($_COOKIE["basket"],true);
        $basket["basket"][] = getProductById($_POST["id"]);
    }else{
        $basket = [];
        $basket["basket"][] = getProductById($_POST["id"]);
    }
    $basket["count"]= count($basket["basket"]);
    $product_basket =  json_encode($basket);
    setcookie("basket","", 0 , "/");

    setcookie("basket",$product_basket, time()+60+60 , "/");
   echo json_encode($_COOKIE["basket"]);
}
