<?php
include_once $_SERVER["DOCUMENT_ROOT"]."/admin/functions.php";

var_dump($_GET);
if (isset($_GET["action"])){
    switch ($_GET["action"]){
        case "":
            break;
        default: break;
    }
}