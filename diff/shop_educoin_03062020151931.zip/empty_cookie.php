<?php
setcookie("basket","", 0 , "/");