<?php

/*база данных*/
$host = "localhost";
$user = "root";
$password = "";
$database = "shop_educoin_db";
$link = null;

$link = mysqli_connect($host, $user, $password, $database);
mysqli_set_charset($link, "utf8");