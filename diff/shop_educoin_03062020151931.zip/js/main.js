var  btnShowMore = document.querySelector("#show-more");
if (btnShowMore){
    btnShowMore.onclick = function () {
        let currentPage = document.querySelector("#current_page");
        let productsOnPage = document.querySelector("#products-on-page");
        let cards_container = document.querySelector("#cards_container");
        cards_container.innerHTML = cards_container.innerHTML + getAjaxResponse('/parts/showmore.php?page='+currentPage.value+'&limit='+productsOnPage.value);
        currentPage.value  = parseInt(currentPage.value, 10) +1;
        let pagBttn = document.querySelector("#pagination"+currentPage.value)
        pagBttn.innerHTML = " <span class=\"page-link\">" + currentPage.value + "</span>";
        pagBttn.classList.add("active");
    }
}


/**
 * добавляет в куки продукт
 * @param item
 */
function addBasket(item) {
    let xhr = new XMLHttpRequest();
    let myLink = location.protocol+'//'+location.hostname+'/parts/add_basket.php';

    xhr.open( "POST", myLink , false);
    xhr.setRequestHeader( "Content-type", "application/x-www-form-urlencoded" );
    xhr.send( "id=" + item.dataset.id);
    let result = JSON.parse(xhr.response);
    let result2 = JSON.parse(result);
    document.querySelector("#basket-count").innerHTML = result2.count;
}



function sendOrder() {
    var orderForm = document.querySelector("#order-form");

    let dataArr = [];
    for(let i = 0; i < orderForm.length; i++) {
        dataArr.push(orderForm[i].name+ "="+orderForm[i].value)
    }
    let xhr = new XMLHttpRequest();
    let myLink = location.protocol+'//'+location.hostname+'/parts/order_basket.php';

    xhr.open( "POST", myLink );
    xhr.setRequestHeader( "Content-type", "application/x-www-form-urlencoded" );

    xhr.send( dataArr.join("&") );
    xhr.onreadystatechange = function() {
        if (this.readyState != 4) return;
        if (this.status == 200) {
            //     let working_container = document.querySelector("#working_container");
            //   working_container.innerHTML =this.response;
            console.dir(this.response);
            let container = document.querySelector("#content_column .container");
            document.querySelector("#basket-count").innerHTML = "0";
            if (this.response == "ok"){
                container.innerHTML = " <div class=\"row\">Заказ оформлен</div>";
            }else {
                container.innerHTML = " <div class=\"row\">Какая то ошибка</div>";
            }
            return;
        }
    }
    return false;

}

/*

var sendOrder = document.querySelector("#send-order");
sendOrder.onclick = function(event) {
    event.preventDefault();
    var orderForm = document.querySelector("#order-form");

    let dataArr = [];
    for(let i = 0; i < orderForm.length; i++) {
        dataArr.push(orderForm[i].name+ "="+orderForm[i].value)
    }
    console.dir(dataArr);
    let xhr = new XMLHttpRequest();
    let myLink = location.protocol+'//'+location.hostname+'/parts/order_basket.php';

    xhr.open( "POST", myLink );
    xhr.setRequestHeader( "Content-type", "application/x-www-form-urlencoded" );

    xhr.send( dataArr.join("&") );
    xhr.onreadystatechange = function() {
        if (this.readyState != 4) return;
        if (this.status == 200) {
       //     let working_container = document.querySelector("#working_container");
         //   working_container.innerHTML =this.response;
            console.dir(this.response);
            return;
        }
    }
    return false;

}*/





/**
 * функция гет аджакс
 * тип строки '/admin/options/product.php?act=create'
 */
function getAjaxResponse(url_string) {
    let myLink = location.protocol+'//'+location.hostname+url_string;
    let xhr = new XMLHttpRequest();
    xhr.open('GET', myLink, false);

    xhr.send();
    if (xhr.status != 200) {
        alert(`Ошибка ${xhr.status}: ${xhr.statusText}`);
        return null;
    } else {
        return xhr.response;
    }
    return null;
}